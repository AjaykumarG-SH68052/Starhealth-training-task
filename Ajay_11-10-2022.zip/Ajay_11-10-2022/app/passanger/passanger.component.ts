import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-passanger',
  templateUrl: './passanger.component.html',
  styleUrls: ['./passanger.component.css']
})
export class PassangerComponent implements OnInit {

  passName= "Jashwanth"
  passId="123"
  password="test"

  constructor() { }

  ngOnInit(): void {
  }

}
