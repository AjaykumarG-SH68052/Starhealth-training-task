import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import {FormsModule}  from '@angular/forms';

import { AppComponent } from './app.component';
import { FlightComponent } from './flight/flight.component';
import { PassangerComponent } from './passanger/passanger.component';
import { AirportComponent } from './airport/airport.component';

@NgModule({
  declarations: [
    AppComponent,
    FlightComponent,
    PassangerComponent,
    AirportComponent
  ],
  imports: [
    BrowserModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent,PassangerComponent]
})
export class AppModule { }
