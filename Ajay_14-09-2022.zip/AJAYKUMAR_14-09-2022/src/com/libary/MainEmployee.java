package com.libary;

public class MainEmployee {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Employee obj = new Employee();
		obj.setSalary(" 50000");
		obj.setId(68052);
		obj.setName("AJAY KUMAR");
		
		Employee obj1 = new Employee();
		
		System.out.println(obj);
		
		System.out.println("Hashcode( )" + obj.hashCode());
		System.out.println("equals method : " + obj1.equals(obj));
		System.out.println(  obj1 == obj);
	

	}
	
	

}
