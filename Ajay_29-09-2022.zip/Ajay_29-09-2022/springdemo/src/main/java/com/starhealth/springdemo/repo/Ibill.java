package com.starhealth.springdemo.repo;

import java.util.List;

import com.starhealth.springdemo.beans.Bill;

public interface Ibill {
	
	public int addInfo(Bill bb);
	
	public List<Bill> selectAllBillData();

}
