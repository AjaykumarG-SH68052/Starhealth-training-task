package com.starhealth.springdemo.repo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.starhealth.springdemo.beans.Bill;

@Repository
public class BillRepoImp implements Ibill {

	Connection con = DbCon.getCon();

	@Override
	public int addInfo(Bill bb) {

		int count = 0;

		try {

			String query = "insert into bill(billNo,name,amount) values(?,?,?)";

			PreparedStatement pt = con.prepareStatement(query);

			pt.setInt(1, bb.getBillNo());
			pt.setString(2, bb.getName());
			pt.setDouble(3, bb.getAmount());

			count = pt.executeUpdate();

			System.out.println(count + "Records Updated...");

		} catch (Exception e) {
			// TODO: handle exception
		}

		return count;
	}

	@Override
	public List<Bill> selectAllBillData() {

		List<Bill> list = new ArrayList<Bill>();

		String query = "select * from bill";

		try {
			PreparedStatement pt = con.prepareStatement(query);

			ResultSet rs = pt.executeQuery();

			while (rs.next()) {

				Bill bb = new Bill();

				bb.setBillNo(rs.getInt("billNo"));
				bb.setName(rs.getString("name"));
				bb.setAmount(rs.getDouble("amount"));

				list.add(bb);

			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return list;
	}

}
