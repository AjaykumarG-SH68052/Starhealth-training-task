package com.starhealth.springdemo.beans;

import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@Data
public class Bill {
	
	private int billNo;
	private String name;
	private double amount;
	

}
