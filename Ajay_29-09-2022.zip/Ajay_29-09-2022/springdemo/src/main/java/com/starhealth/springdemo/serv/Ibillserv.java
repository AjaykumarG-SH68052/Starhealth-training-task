package com.starhealth.springdemo.serv;

import java.util.List;

import com.starhealth.springdemo.beans.Bill;

public interface Ibillserv {

	public int addInfo(Bill bb);

	public List<Bill> selectAllBillData();

}
