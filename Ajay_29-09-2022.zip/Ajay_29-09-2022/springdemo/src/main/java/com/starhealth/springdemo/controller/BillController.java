package com.starhealth.springdemo.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.starhealth.springdemo.beans.Bill;
import com.starhealth.springdemo.repo.Ibill;

@Controller
@RequestMapping("/api/v1/bill")
public class BillController {
	
	/*
	 * @RequestMapping(value="/dis", method = RequestMethod.POST)
	 * 
	 * @ResponseBody public String dis(Bill bb) {
	 * 
	 * return bb.toString(); }
	 */
	
	@Autowired
	Ibill serv;
	
	@RequestMapping(value="/add", method = RequestMethod.POST)
	@ResponseBody
	public String addInfo(Bill bb) {
		
		int count = serv.addInfo(bb);
		
		return count+ "Records added successfully...";
		
		
	}
	
	
	@RequestMapping("/all")
	public String selectAllBillData(HttpSession session) {
		
	List<Bill> list = serv.selectAllBillData();
	
	session.setAttribute("bill", list);
	return "success";
	
	
	}
	
}
