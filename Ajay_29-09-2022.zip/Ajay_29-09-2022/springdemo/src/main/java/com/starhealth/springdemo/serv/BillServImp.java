package com.starhealth.springdemo.serv;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.starhealth.springdemo.beans.Bill;
import com.starhealth.springdemo.repo.Ibill;

@Service
public class BillServImp implements Ibillserv {

	@Autowired
	Ibill ib;

	@Override
	public int addInfo(Bill bb) {

		return ib.addInfo(bb);
	}

	@Override
	public List<Bill> selectAllBillData() {
		return ib.selectAllBillData();
	}

}
