package com.java.exception;

public class Test2 extends Thread{
	 public void run() {
		 System.out.println("test one 2");
	 }

}
