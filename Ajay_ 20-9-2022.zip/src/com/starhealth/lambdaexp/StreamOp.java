package com.starhealth.lambdaexp;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;

public class StreamOp {

	public static void main(String[] args) {

		List<Integer> refff = new ArrayList<Integer>();

		refff.add(1000);
		refff.add(3000);
		refff.add(5000);
		refff.add(4000);
		refff.add(2000);

		Stream<Integer> ss = refff.stream();

		Optional<Integer> op = ss.reduce((s1, s2) -> {
			return s1 + s2;
		});

		if (op.isPresent()) {

			System.out.println("Sum of Salaries " + op.get());

		}

		else {

			System.out.println(op.get());

		}

		Stream<Integer> s1 = Stream.of(10, 30, 20, 40, 50);

		s1.forEach((Integer i) -> {
			System.out.println(i);
		});

		String fruits[] = { "apple", "mango", "grapes", "pear", "banana" };

		Stream<String> oj = Arrays.stream(fruits);

		oj.filter((String s) -> {
			return s.length() > 4;
		}).forEach((s) -> {
			System.out.println(s);
		});

		List<String> lis = Arrays.asList(fruits);

		Stream<String> obj = lis.stream();

		obj.map((String name) -> {
			return name.toUpperCase();
		}).filter((name) -> {
			return name.length() > 5;
		}).forEach(System.out::println);

	}

}
