package com.starhealth.lambdaexp;

public class FunctionDemo {

	public static void main(String[] args) {

		/*
		 * FuncInt ref = (a,b) -> {return a+b;};
		 * 
		 * int result = ref.add(10, 20);
		 * 
		 * System.out.println(result);
		 */

		/*
		 * FuncInt ref = ()-> {return 22;}; int num = ref.show();
		 * 
		 * System.out.println(num);
		 * 
		 * 
		 */

		/*
		 * FuncInt ref = (String s)-> {System.out.println("Hi" + s);};
		 * 
		 * ref.display("Ajay");
		 */

		/*
		 * FuncInt ref = ()-> {System.out.println("Hello !!");};
		 * 
		 * ref.show();
		 */

		FuncInt.mul();

		FuncInt ref = (a) -> {
			return a > 5;
		};

		System.out.println(ref.dis(2));

	}

}
