package training.java.opps.inheritance;

public class Child extends Object {
	
	public Child() {
		super();
		System.out.println("Child constuctor is called");
		// TODO Auto-generated constructor stub
	}

	public void info() {
		System.out.println("info method");
	}
	
	public void department() {
		System.out.println("department method");
	}

}
