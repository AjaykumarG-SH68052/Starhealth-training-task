package training.java.opps.polymorphism;

public class Phone {
	
	public void iphone() {
		System.out.println("iphone 16 pro max++");
	}
	
	public static void main(String[] args) {
		
//		overiding method
		Laptop obj1 = new Ipad();
		obj1.display();
		
		Laptop obj2 = new Laptop();
		obj2.display();
	}

}
