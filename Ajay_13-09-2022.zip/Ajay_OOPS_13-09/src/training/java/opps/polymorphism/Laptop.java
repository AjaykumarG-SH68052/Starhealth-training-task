package training.java.opps.polymorphism;

public class Laptop {
	
	public void procesor() {
		System.out.println("I5 and I3");
	}
	public void display() {
		System.out.println("All  display  ");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Laptop a = new Laptop();
		a.procesor();
		Laptop a1 = new Ipad();
		a1.procesor();

	}

}
