package training.java.opps.polymorphism;

public class Ipad  extends Laptop{
	public void version() {
		System.out.println("Iphone lastest Version 15 pro max");
	
	}
	@Override
	public void display() {
		System.out.println("all phone version display");
	}
	
	public static void sum() {
		System.out.println("default sum() method");
	}
	public static void sum(int a,int b) {
		System.out.println(a+b);
	}
	public static void sum(int a,int b, int c) {
		System.out.println(a+b + c);
	}
	
	public  static void main(String[] args) {
//		method overloading
		sum(2,3);
		sum(2,3, 3);
		
		
	}

}
