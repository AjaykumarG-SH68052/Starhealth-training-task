package training.java.opps.abstraction;

public abstract class Tamil {
	
	public abstract void child();
	
	
	   public void sleep() {
	    System.out.println("Zzz");
	  }
	  
}
