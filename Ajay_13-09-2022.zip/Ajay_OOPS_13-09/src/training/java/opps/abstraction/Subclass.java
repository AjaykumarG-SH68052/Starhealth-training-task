package training.java.opps.abstraction;

class Subclass extends Tamil {
	
	
	  public void child() {
	    
	    System.out.println("child method called. ");
	  }
	}