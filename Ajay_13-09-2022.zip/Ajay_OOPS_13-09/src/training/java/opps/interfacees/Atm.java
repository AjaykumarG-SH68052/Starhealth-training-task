package training.java.opps.interfacees;

public interface Atm {
	public abstract  void print(); 

	
	public abstract  void withdrawl(); 
}
