package training.java.opps.interfacees;

public abstract class SbiBank implements Atm{
	
	public void print() {
		System.out.println("print method by interface");
	}

	
}
