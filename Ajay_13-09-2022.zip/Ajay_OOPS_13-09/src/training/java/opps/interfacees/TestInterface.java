package training.java.opps.interfacees;

public class TestInterface {
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SbiBank obj = new SbiBank() {

			@Override
			public void withdrawl () {
				// TODO Auto-generated method stub
				System.out.println("withdrawl method");
			}
		};
		obj.withdrawl();
		obj.print();

	}

}
