package com.starhealth.springrestapi.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;
import lombok.NoArgsConstructor;


@NoArgsConstructor
@Data

@Entity
@Table(name="Students_info")
public class Students {

	@Id
	private int sid;
	private String sname;
	private double fee;
}
