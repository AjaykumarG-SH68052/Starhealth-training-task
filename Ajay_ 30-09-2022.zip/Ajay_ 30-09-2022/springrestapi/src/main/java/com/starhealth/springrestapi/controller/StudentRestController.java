package com.starhealth.springrestapi.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.starhealth.springrestapi.entity.Students;
import com.starhealth.springrestapi.service.IStudentService;

@RestController
@RequestMapping("api/v1/students")
public class StudentRestController {

	@Autowired
	IStudentService service;

	@PostMapping("/add")
	public Students add(@RequestBody Students stud) {

		return service.addStudent(stud);

	}

	@PutMapping("/update")
	public Students update(@RequestBody Students stud) {

		return service.updateStudent(stud);

	}

	@DeleteMapping("/delete{sid}")
	public String delete(int sid) {
		return "Record deleted successfully";
	}

}
